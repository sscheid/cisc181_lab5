package pkgEnum;

public enum eAction {

	Draw, Fold, Bet, Raise, Sit, Leave, StartGameBlackJack, StartGamePoker, Deal, GameState, TableState, ScoreGame;
}