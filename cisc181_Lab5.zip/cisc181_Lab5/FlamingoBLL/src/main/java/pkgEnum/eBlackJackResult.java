package pkgEnum;

public enum eBlackJackResult {

	LOSE, WIN, TIE;
}
