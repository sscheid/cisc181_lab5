package pkgEnum;

public enum eCardDestination {
	PLAYER, COMMON;
}
