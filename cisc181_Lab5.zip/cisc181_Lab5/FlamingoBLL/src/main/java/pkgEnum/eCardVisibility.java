package pkgEnum;

public enum eCardVisibility {
	ME, EVERYONE;
}
