package pkgEnum;

public enum eGameType {

	BLACKJACK, POKER;
}
