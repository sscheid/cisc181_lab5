package pkgEnum;

public enum ePlayerIdentity {
	ME, OTHER;
}
