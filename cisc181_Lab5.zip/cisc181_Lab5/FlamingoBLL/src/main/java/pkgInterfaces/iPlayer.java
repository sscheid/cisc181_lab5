package pkgInterfaces;

import java.util.UUID;

public interface iPlayer {

	public String getPlayerName();
	public int getiPlayerPosition();
	public boolean isME();
}
