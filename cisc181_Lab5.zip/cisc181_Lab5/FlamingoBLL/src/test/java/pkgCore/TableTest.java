package pkgCore;

import static org.junit.Assert.*;

import org.junit.Test;

public class TableTest {

	@Test
	public void TableTest1() {
		
		//	TODO: Create 2 players.
		//			Add them to the a Table
		//			Ensure that each are added to the table
		//			Remove each from the Table, ensure they are removed from the table.
	}

}
